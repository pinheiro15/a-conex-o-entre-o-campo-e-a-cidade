let player;
let items = [];
let collected = 0;
let totalItems = 6;
let partyStarted = false;

function setup() {
  createCanvas(800, 600);
  player = createVector(width / 2, height - 50);

  // Criar itens do campo e da cidade
  for (let i = 0; i < totalItems; i++) {
    items.push({
      pos: createVector(random(50, width - 50), random(50, height - 100)),
      type: i < 3 ? 'campo' : 'cidade',
      collected: false
    });
  }
}

function draw() {
  background(100, 200, 100);

  if (!partyStarted) {
    // Mostrar itens
    for (let item of items) {
      if (!item.collected) {
        fill(item.type === 'campo' ? 'orange' : 'blue');
        ellipse(item.pos.x, item.pos.y, 30, 30);
      }
    }

    // Mostrar jogador
    fill(255, 0, 0);
    ellipse(player.x, player.y, 40, 40);

    // Verificar colisão com itens
    for (let item of items) {
      if (!item.collected && dist(player.x, player.y, item.pos.x, item.pos.y) < 35) {
        item.collected = true;
        collected++;
      }
    }

    // Verificar se pegou todos
    if (collected === totalItems) {
      partyStarted = true;
    }

    handleMovement();
  } else {
    showParty();
  }
}

function handleMovement() {
  if (keyIsDown(LEFT_ARROW)) {
    player.x -= 5;
  }
  if (keyIsDown(RIGHT_ARROW)) {
    player.x += 5;
  }
  if (keyIsDown(UP_ARROW)) {
    player.y -= 5;
  }
  if (keyIsDown(DOWN_ARROW)) {
    player.y += 5;
  }
}

function showParty() {
  background(50, 0, 100);
  fill(255);
  textSize(32);
  textAlign(CENTER);
  text("Festa no Campo e Cidade!", width / 2, height / 2);

  // Efeitos de festa
  for (let i = 0; i < 100; i++) {
    fill(random(255), random(255), random(255));
    ellipse(random(width), random(height), 5, 5);
  }
}